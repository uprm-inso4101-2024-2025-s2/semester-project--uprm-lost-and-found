from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from database.database import get_db
from database.models.models import FoundItem
import os
import shutil

router = APIRouter()

UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@router.post("/found-items/")
def submit_found_item(
    description: str = Form(...),
    found_date: str = Form(...),
    location: str = Form(...),
    user_id: int = Form(...),
    photo: UploadFile = File(None),
    db: Session = Depends(get_db)
):
    """Handles form submission for a new found item."""
    photo_path = ""
    if photo:
        file_ext = os.path.splitext(photo.filename)[-1]
        file_name = f"{user_id}_{photo.filename}"
        photo_path = os.path.join(UPLOAD_FOLDER, file_name)
        with open(photo_path, "wb") as buffer:
            shutil.copyfileobj(photo.file, buffer)

    new_item = FoundItem(
        description=description,
        found_date=found_date,
        location=location,
        photo=photo_path,
        user_id=user_id  # <-- IMPORTANT: You must add user_id to the model (see note below)
    )
    db.add(new_item)
    db.commit()
    db.refresh(new_item)
    return {"message": "Found item submitted", "id": new_item.id}

@router.get("/my-cases/{user_id}")
def get_user_found_items(user_id: int, db: Session = Depends(get_db)):
    """Returns all found item reports submitted by a user."""
    items = db.query(FoundItem).filter(FoundItem.user_id == user_id).all()
    if not items:
        return []
    return [
        {
            "id": item.id,
            "description": item.description,
            "found_date": item.found_date,
            "location": item.location,
            "photo": item.photo,
        }
        for item in items
    ]
