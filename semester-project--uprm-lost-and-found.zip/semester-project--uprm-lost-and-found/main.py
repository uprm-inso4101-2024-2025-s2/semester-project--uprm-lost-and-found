from fastapi import FastAPI, Depends
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from database.database import get_db, Base, engine
from database.handlers.users_handler import router as users_router
from database.handlers.found_items_handler import router as found_items_router

import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = FastAPI()

# ✅ Serve static files like images
app.mount("/static", StaticFiles(directory="static"), name="static")

# ✅ Include routers
app.include_router(found_items_router)
# app.include_router(users_router, prefix="/api")

@app.get("/")
def home():
    return {"message": "Lost & Found UPRM API is running"}

@app.get("/test-db")
def test_connection(db: Session = Depends(get_db)):
    return {"message": "✅ Connected to MySQL on Railway!"}

# ✅ Create tables on startup (only once)
Base.metadata.create_all(bind=engine)
